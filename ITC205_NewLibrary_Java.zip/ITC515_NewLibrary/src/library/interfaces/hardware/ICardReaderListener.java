package library.interfaces.hardware;

public interface ICardReaderListener {
	
	public void cardSwiped(int cardData);

}
