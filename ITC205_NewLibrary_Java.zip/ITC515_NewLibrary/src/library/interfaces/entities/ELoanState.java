package library.interfaces.entities;

public enum ELoanState {
	
	PENDING, CURRENT, OVERDUE, COMPLETE

}
