package library.interfaces;

public interface IMainListener {

	public void borrowBooks();

}
